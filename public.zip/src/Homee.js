import React from 'react'
import Navbar from './components/Navbar'
import Home from './Home'

const Homee = () => {
  return (
    <div>
      <Navbar/>
        <Home/> 
        
    </div>
  )
}

export default Homee