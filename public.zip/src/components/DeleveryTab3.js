import React from 'react'

const DeleveryTab3 = () => {
  return (
    <div className="containertab3">
        <div className="DeleveryTab3">
            <span>Couriers are very busy 🔥
</span>
<p>
Delivery in 4 hours is not yet available

</p>
The order form will return when the demand decreases.

        </div>
    </div>
  )
}

export default DeleveryTab3