# LinkedIn UI clone using React.

This is a basic UI clone (non responsive as of now) of LinkedIn India Landing page. 

Note: LinkedIn regularly changes its UI design, so the UI by this code will be different.

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).
"# ui-benzo" 
